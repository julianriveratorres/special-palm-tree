class ApplicationMailer < ActionMailer::Base
  default from: 'haydenbourgeois04@gmail.com'
  layout 'bootstrap-mailer'
end
