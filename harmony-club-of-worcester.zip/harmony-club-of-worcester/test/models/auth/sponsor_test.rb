require "test_helper"

class Auth::SponsorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
