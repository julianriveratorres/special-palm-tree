module Auth::SponsorsHelper
end
