module Auth
  def self.table_name_prefix
    'auth_'
  end
end
